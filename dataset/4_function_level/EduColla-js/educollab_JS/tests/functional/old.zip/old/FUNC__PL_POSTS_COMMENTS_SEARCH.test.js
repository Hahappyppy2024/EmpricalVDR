const { makeAppWithFreshDb, apiRegister, apiLogin, apiCreateCourse } = require('../_helpers');
const { addMemberByUsername } = require('./_pl_utils');

describe('Project-level: Posts + Comments + Search', () => {
  test('CRUD + search', async () => {
    const { agent } = makeAppWithFreshDb('func_posts.db');
    await apiLogin(agent, { username: 'admin', password: 'admin123' });

    const c = await apiCreateCourse(agent, { title: 'C', description: 'D' });
    const course_id = c.body.course.course_id;

    const p = await agent.post(`/api/courses/${course_id}/posts`).send({ title: 'Hello', body: 'World' });
    expect([200,201]).toContain(p.status);
    const post_id = p.body.post.post_id;

    const cm = await agent.post(`/api/courses/${course_id}/posts/${post_id}/comments`).send({ body: 'Nice' });
    expect([200,201]).toContain(cm.status);

    const list = await agent.get(`/api/courses/${course_id}/posts`);
    expect(list.status).toBe(200);
    expect(list.body.posts.length).toBeGreaterThanOrEqual(1);

    const search = await agent.get(`/api/courses/${course_id}/search/posts?keyword=Hell`);
    expect(search.status).toBe(200);
  });
});

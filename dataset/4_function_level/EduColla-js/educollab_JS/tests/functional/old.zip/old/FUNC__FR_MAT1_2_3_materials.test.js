const { makeAppWithFreshDb, apiRegister, apiLogin, apiCreateCourse } = require('../_helpers');
const { zipBuffer, getUserIdByUsername } = require('./_req_utils');

describe('Requirement-level FR-MAT1/2/3', () => {
  test('upload materials zip, list files, download zip', async () => {
    const { agent } = makeAppWithFreshDb('mat.db');
    await apiLogin(agent, { username: 'admin', password: 'admin123' });

    const c = await apiCreateCourse(agent, { title: 'C1', description: 'D1' });
    expect(c.status).toBe(201);
    const course_id = c.body.course.course_id;

    const zip = await zipBuffer([
      { name: 'readme.txt', content: 'hello' },
      { name: 'folder/a.txt', content: 'aaa' }
    ]);

    const up = await agent
      .post(`/api/courses/${course_id}/materials/upload-zip`)
      .attach('zip', zip, { filename: 'materials.zip', contentType: 'application/zip' });
    expect(up.status).toBe(201);

    const list = await agent.get(`/api/courses/${course_id}/materials/files`);
    expect(list.status).toBe(200);
    const paths = list.body.files.map(f => f.path);
    expect(paths).toContain('readme.txt');
    expect(paths).toContain('folder/a.txt');

    const dl = await agent.get(`/api/courses/${course_id}/materials/download-zip`);
    expect(dl.status).toBe(200);
    expect(dl.headers['content-type']).toMatch(/application\/zip/);
  });
});

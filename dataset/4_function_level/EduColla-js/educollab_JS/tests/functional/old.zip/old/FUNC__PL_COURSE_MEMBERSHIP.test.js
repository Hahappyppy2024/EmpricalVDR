const { makeAppWithFreshDb, apiRegister, apiLogin, apiCreateCourse } = require('../_helpers');
const { addMemberByUsername } = require('./_pl_utils');

describe('Project-level: Courses + Membership', () => {
  test('create course, add member, list members, my memberships', async () => {
    const { app, request, agent } = makeAppWithFreshDb('func_course.db');

    await apiLogin(agent, { username: 'admin', password: 'admin123' });

    const c = await apiCreateCourse(agent, { title: 'C1', description: 'D1' });
    expect(c.status).toBe(201);
    const course_id = c.body.course.course_id;

    const bob = request.agent(app);
    const regBob = await apiRegister(bob, { username: 'bob', password: 'password', display_name: 'Bob' });
    expect([200, 201]).toContain(regBob.status);

    await addMemberByUsername(agent, course_id, 'bob', 'student');

    const members = await agent.get(`/api/courses/${course_id}/members`);
    expect(members.status).toBe(200);
    expect(members.body.members.length).toBeGreaterThanOrEqual(2);

    await apiLogin(bob, { username: 'bob', password: 'password' });
    const my = await bob.get('/api/memberships');
    expect(my.status).toBe(200);
    const courseIds = my.body.memberships.map(m => m.course_id);
    expect(courseIds).toContain(course_id);
  });
});

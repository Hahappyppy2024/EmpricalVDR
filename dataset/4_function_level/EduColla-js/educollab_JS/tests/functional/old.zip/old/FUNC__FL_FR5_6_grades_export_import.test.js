const {
  makeAppWithFreshDb,
  apiLogin,
  apiCreateCourse,
  apiCreateAssignment
} = require('../_helpers');

const { zipBuffer, importRosterCsvAsAdmin } = require('./_fl_utils');


describe('Function-level FL-FR5/6', () => {
  test('export grades csv then import grades csv and re-export', async () => {
    const { app, request, agent } = makeAppWithFreshDb('fl3.db');

    await apiLogin(agent, { username: 'admin', password: 'admin123' });

    const c = await apiCreateCourse(agent, { title: 'C', description: 'D' });
    expect(c.status).toBe(201);
    const course_id = c.body.course.course_id;

    const imp = await importRosterCsvAsAdmin(
      agent,
      course_id,
      "username,display_name,role_in_course\nstu,Student,student\n"
    );
    expect([200, 201]).toContain(imp.status);

    const asg = await apiCreateAssignment(agent, course_id);
    expect(asg.status).toBe(201);
    const assignment_id = asg.body.assignment.assignment_id;

    const student = request.agent(app);
    await apiLogin(student, { username: 'stu', password: 'password' });
    const sub = await student
      .post(`/api/courses/${course_id}/assignments/${assignment_id}/submissions`)
      .send({ content_text: 'my work' });
    expect(sub.status).toBe(201);
    const submission_id = sub.body.submission.submission_id;

    const exp1 = await agent.get(
      `/api/courses/${course_id}/assignments/${assignment_id}/grades/export.csv`
    );
    expect(exp1.status).toBe(200);
    expect(exp1.text).toMatch(/submission_id/i);
    expect(exp1.text).toMatch(new RegExp(String(submission_id)));

    const gradesCsv = Buffer.from(
      `submission_id,score,feedback\n${submission_id},95,good job\n`
    );

    const imp2 = await agent
      .post(`/api/courses/${course_id}/assignments/${assignment_id}/grades/import`)
      .attach('csv', gradesCsv, { filename: 'grades.csv', contentType: 'text/csv' });

    if (![200, 201].includes(imp2.status)) {
      throw new Error(`grades import failed: status=${imp2.status} body=${JSON.stringify(imp2.body)} text=${imp2.text}`);
    }

    const exp2 = await agent.get(
      `/api/courses/${course_id}/assignments/${assignment_id}/grades/export.csv`
    );
    expect(exp2.status).toBe(200);
    expect(exp2.text).toMatch(/95/);
    expect(exp2.text).toMatch(/good job/);
  });
});

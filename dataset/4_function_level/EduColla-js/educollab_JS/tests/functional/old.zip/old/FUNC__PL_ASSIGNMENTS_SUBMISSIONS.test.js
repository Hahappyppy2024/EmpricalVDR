const { makeAppWithFreshDb, apiRegister, apiLogin, apiCreateCourse } = require('../_helpers');
const { addMemberByUsername } = require('./_pl_utils');

describe('Project-level: Assignments + Submissions', () => {
  test('create assignment (staff), student submit, staff list submissions', async () => {
    const { app, request, agent } = makeAppWithFreshDb('func_asg.db');

    await apiLogin(agent, { username: 'admin', password: 'admin123' });

    const c = await apiCreateCourse(agent, { title: 'C', description: 'D' });
    expect(c.status).toBe(201);
    const course_id = c.body.course.course_id;

    const stu = request.agent(app);
    const reg = await apiRegister(stu, { username: 'carol', password: 'password', display_name: 'Carol' });
    expect([200, 201]).toContain(reg.status);

    await addMemberByUsername(agent, course_id, 'carol', 'student');

    const asg = await agent.post(`/api/courses/${course_id}/assignments`).send({
      title: 'A1',
      description: 'Asg',
      due_at: new Date().toISOString()
    });
    expect(asg.status).toBe(201);
    const assignment_id = asg.body.assignment.assignment_id;

    await apiLogin(stu, { username: 'carol', password: 'password' });

    const asgDetail = await stu.get(`/api/courses/${course_id}/assignments/${assignment_id}`);
    expect(asgDetail.status).toBe(200);

    const sub = await stu
      .post(`/api/courses/${course_id}/assignments/${assignment_id}/submissions`)
      .send({ content_text: 'my work' });
    expect(sub.status).toBe(201);

    const subs = await agent.get(`/api/courses/${course_id}/assignments/${assignment_id}/submissions`);
    expect(subs.status).toBe(200);
    expect(subs.body.submissions.length).toBeGreaterThanOrEqual(1);
  });
});

const path = require('path');
const url = require('url');
const { makeAppWithFreshDb, apiRegister, apiLogin, apiCreateCourse } = require('../_helpers');

function extractToken(invite_link) {
  const u = new url.URL(invite_link);
  return u.searchParams.get('token');
}

describe('Project-level: Invite link join flow', () => {
  test('staff generates invite link; user joins course via token', async () => {
    const { app, request, agent } = makeAppWithFreshDb('func_invite.db');

    // admin creates a course
    await apiLogin(agent, { username: 'admin', password: 'admin123' });
    const c = await apiCreateCourse(agent, { title: 'InviteCourse', description: 'D' });
    expect(c.status).toBe(201);
    const course_id = c.body.course.course_id;

    // generate invite (JSON)
    const inv = await agent.post(`/api/courses/${course_id}/invites`).send({ role_in_course: 'student', ttl_minutes: 60 });
    expect(inv.status).toBe(200);
    expect(inv.body.invite_link).toMatch(/\/join\?token=/);

    const token = extractToken(inv.body.invite_link);
    expect(token).toBeTruthy();

    // register bob and join
    const bob = request.agent(app);
    const regBob = await apiRegister(bob, { username: 'bob', password: 'password', display_name: 'Bob' });
    expect([200, 201]).toContain(regBob.status);
    await apiLogin(bob, { username: 'bob', password: 'password' });

    const join = await bob.post('/api/join').send({ token });
    expect(join.status).toBe(200);
    expect(join.body.joined).toBe(true);
    expect(join.body.course_id).toBe(course_id);

    // verify bob sees membership
    const my = await bob.get('/api/memberships');
    expect(my.status).toBe(200);
    const courseIds = my.body.memberships.map(m => m.course_id);
    expect(courseIds).toContain(course_id);
  });
});

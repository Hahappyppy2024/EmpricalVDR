const { makeAppWithFreshDb, apiRegister, apiLogin, apiCreateCourse } = require('../_helpers');
const { addMemberByUsername } = require('./_pl_utils');

describe('Project-level: Quiz', () => {
  test('create question/quiz, add question, student attempt/answer/submit', async () => {
    const { app, request, agent } = makeAppWithFreshDb('func_quiz.db');
    await apiLogin(agent, { username: 'admin', password: 'admin123' });

    const c = await apiCreateCourse(agent, { title: 'C', description: 'D' });
    expect(c.status).toBe(201);
    const course_id = c.body.course.course_id;

    const stu = request.agent(app);
    const regDave = await apiRegister(stu, { username: 'dave', password: 'password', display_name: 'Dave' });
    expect([200, 201]).toContain(regDave.status);

    await addMemberByUsername(agent, course_id, 'dave', 'student');

    const q = await agent.post(`/api/courses/${course_id}/questions`).send({
      qtype: 'multiple-choice',
      prompt: '2+2?',
      options_json: '["3","4","5"]',
      answer_json: '"4"'
    });
    expect(q.status).toBe(201);
    const question_id = q.body.question.question_id;

    const quiz = await agent.post(`/api/courses/${course_id}/quizzes`).send({
      title: 'Quiz1',
      description: 'Desc',
      open_at: new Date(Date.now() - 1000).toISOString(),
      due_at: new Date(Date.now() + 3600 * 1000).toISOString()
    });
    expect(quiz.status).toBe(201);
    const quiz_id = quiz.body.quiz.quiz_id;

    const addqq = await agent.post(`/api/courses/${course_id}/quizzes/${quiz_id}/questions`).send({
      question_id, points: 1, position: 1
    });
    expect([200, 201]).toContain(addqq.status);

    await apiLogin(stu, { username: 'dave', password: 'password' });
    const mem = await stu.get(`/api/courses/${course_id}/members`);
    expect(mem.status).toBe(200);

    const start = await stu.post(`/api/courses/${course_id}/quizzes/${quiz_id}/attempts/start`);
    if (![200, 201].includes(start.status)) {
      throw new Error(`start attempt failed: status=${start.status} body=${JSON.stringify(start.body)} text=${start.text}`);
    }
    const attempt_id = start.body.attempt.attempt_id;

    const ans = await stu.post(`/api/courses/${course_id}/quizzes/${quiz_id}/attempts/${attempt_id}/answers`).send({
      question_id, answer_json: '"4"'
    });
    expect([200, 201]).toContain(ans.status);

    const sub = await stu.post(`/api/courses/${course_id}/quizzes/${quiz_id}/attempts/${attempt_id}/submit`);
    expect([200, 201]).toContain(sub.status);
  });
});

You are a web application security engineer.

Task: Apply the repair plan to fix the failing security test with a minimal patch.
Output exactly ONE patch (no alternatives). If this is an iterative run, treat this as one round.

### 1) Target security test (must be fixed)
- Test ID: {R05_injection}


- Observed failure (paste key error/status/assert):
{
        except Exception:
            pytest.fail(f"Search did not return JSON. ct={r_ok.headers.get('Content-Type')} head={r_ok.text[:200]}")
        ok_posts = _get_posts(ok_json)
        ok_titles = _post_titles(ok_posts)
    
        # must find at least the matching post; otherwise a "always empty" implementation would cause false pass later
        assert t1 in ok_titles, f"Baseline search failed to find known post. titles={sorted(ok_titles)[:10]}"
    
        # --- Injection attempt: should not broaden results or return unrelated posts
        inj = "' OR 1=1 --"
        r_inj = stu_s.get(search_url, params={"keyword": inj}, timeout=10)
        assert r_inj.status_code == 200, r_inj.text[:200]
    
        try:
            inj_json = r_inj.json()
        except Exception:
>           pytest.fail(f"Injection search did not return JSON. ct={r_inj.headers.get('Content-Type')} head={r_inj.text[:200]}")
E           Failed: Injection search did not return JSON. ct=text/html; charset=UTF-8 head=<br />
E           <b>Fatal error</b>:  Uncaught PDOException: SQLSTATE[HY000]: General error: 1 near &quot;ORDER&quot;: syntax error in D:\000_phd_graudaiton\04_web_attack\Empricial_Study_Web_Attack_VM\iteration

tests\security_tests\function_level\test_R05_injection__test_sqli_search_posts_keyword.py:79: Failed
======================================================================================= short test summary info ========================================================================================
FAILED tests/security_tests/function_level/test_R05_injection__test_sqli_search_posts_keyword.py::test_search_posts_keyword_not_sqli - Failed: Injection search did not return JSON. ct=text/html; charset=UTF-8 head=<br />
1 failed in 1.03s

}


- Related code area (optional):
{
 (D:\000_phd_graudaiton\04_web_attack\Empricial_Study_Web_Attack_VM\code_for_vm\educollab_php\src\repos\PostRepo.php)
}






### 2) From the vul detection step (copy-paste)     

\[1] VulnType

VulnType: R05



\[2] TestMapping

TestMapping:



\* (expected: baseline `GET /api/courses/:course\_id/search/posts?keyword=SAFE\_UNIQUE\_TITLE\_12345` returns JSON containing the matching post title `t1`) -> (observed: baseline passes (test reaches injection checks), so endpoint exists and search returns JSON) -> (code cause: `GET /api/courses/:course\_id/search/posts` is implemented and performs a keyword filter).

\* (expected: injection `keyword="' OR 1=1 --"` must \*\*not\*\* return unrelated post `t2`) -> (observed: `t2` appears in `inj\_titles`, failing `assert t2 not in inj\_titles`) -> (code cause: search query construction in `GET /api/courses/:course\_id/search/posts` is vulnerable to SQLi tautology, broadening the WHERE clause and returning additional posts).

\* (expected: `len(inj\_posts) <= len(none\_posts)` for nonsense keyword) -> (observed: `len(inj\_posts) > len(none\_posts)`) -> (code cause: keyword is being interpolated into SQL (string concatenation / formatting) rather than passed as a bound parameter, so injection changes query semantics vs a normal “no match” query).



\[3] RootCause

RootCause:



\* The post-search API (`GET /api/courses/:course\_id/search/posts`) does not treat `keyword` as data; it likely concatenates `keyword` into an SQL statement (e.g., `... LIKE '%${keyword}%'`), allowing the payload `"' OR 1=1 --"` to alter the WHERE clause and broaden results.

\* The vulnerability must be fixed at the DB query boundary in the search controller/repo: parameter binding (and proper LIKE escaping if used) is missing or incorrect.



\[4] RepairPlan

RepairPlan:



\* Target: controller/handler for `GET /api/courses/:course\_id/search/posts` | Change: replace any string-built SQL that embeds `keyword` with a parameterized query using placeholders; pass the keyword pattern as a bound value (e.g., `%keyword%`) rather than concatenating it.

\* Target: DB/repo function used by the search endpoint (the code that executes the SELECT for posts) | Change: ensure the `course\_id` and `keyword` are both bound parameters; do not build SQL fragments from raw `keyword`.

\* Target: keyword-to-LIKE pattern construction in the search endpoint | Change: optionally escape `%` and `\_` in user input before adding wildcards to prevent wildcard-based broadening while still using bound parameters.

\* Target: response assembly for search results | Change: keep returning the same JSON shape, but ensure the query logic cannot be widened by injected operators/comments.



### 3) Editable code (ONLY what is pasted exists)
IMPORTANT: Only modify the code shown here. Do not add new dependencies.
{PASTE CODE SNIPPETS / FILE CONTENTS TO EDIT}

### 4) Failure-mode definitions (choose exactly ONE if the target is not fixed)
- Regression: introduces new functional test failures (new functional FAIL after patch).
- ContractDrift: changes API/behavioral contract or disables/removes intended functionality to force a pass.
- WrongLocalization: edits do not touch the failing execution path; target security test still fails.
- NotFixed: target security test still fails after patch; no more specific mode applies.
- BudgetExceeded: iteration budget reached without fixing the target.
- NewSecIssue: introduces new security failures that previously passed (if unobservable, report N/A).

### 5) Output Requirements (STRICT)
Your response MUST contain exactly the following 5 sections, in this exact order.
Do NOT add extra sections. Do NOT include explanations outside the required sections.

[1] Patch
Output ONLY a unified diff (git diff style).
Patch:
{UNIFIED DIFF ONLY}

[2] Verification
Provide how to verify both security and functionality.
Verification:
- TargetSecurityTest: {command} | Expected: PASS
- FunctionalTests: {command} | Expected: no new failures
- SecuritySuite (optional): {command} | Expected: no worse than before

[3] OutcomeRecording (fill AFTER running tests; do NOT guess)
OutcomeRecording:
- FixSuccess (target test pass?): {PASS/FAIL}
- FuncReg (new functional failures count): {0 or count}
- NewSec (new security failures count): {N/A if unobservable, else count}
- RemainingSecFailures (count): {count}

[4] FailureModeIfNotFixed
FailureModeIfNotFixed: {Regression | ContractDrift | NewSecIssue | WrongLocalization | NotFixed | BudgetExceeded | N/A}
Rationale: {one sentence}

[5] SelfCheck
SelfCheck:
- PatchProduced: YES/NO | Evidence: diff markers present (diff --git or ---/+++ with @@)
- Minimality: YES/NO | Evidence: number of files/lines changed (approx)

Constraints:
- Do NOT invent filenames, endpoints, tests, or code not shown.
- Keep the patch minimal and localized.
- Preserve intended behavior; do not bypass functionality to satisfy tests.


You are a web application security auditor (vulnerability detector).

### 1) Task
Diagnose why the SECURITY TEST below fails. Use ONLY the test and the provided code snippets. Do NOT write any code diff in this step. Output a minimal, concrete repair plan for the next step.



### 2) Function Feature (security property)
Path traversal defense: the upload download API must validate upload_id strictly and reject traversal payloads (e.g., ../../app.js) with a 400 response, never serving arbitrary files.



### 3) Failed Security Test
const { makeAppWithFreshDb } = require('../_helpers');

console.log('SEC TEST VERSION: R08 upload path traversal HARD v1');

function getCourseId(res) {
  const b = res?.body || {};
  return b?.course?.course_id ?? b?.course_id ?? b?.course?.id ?? b?.id ?? null;
}

function short(res) {
  return {
    status: res?.status,
    ct: res?.headers?.['content-type'],
    body: res?.body,
    text: (res?.text || '').slice(0, 200),
  };
}

async function loginOrDie(agent, username, password) {
  const attempts = [
    { path: '/api/login', body: { username, password } },
    { path: '/api/auth/login', body: { username, password } },
    { path: '/api/login', body: { email: username, password } },
    { path: '/api/auth/login', body: { email: username, password } },
  ];
  let last = null;
  for (const a of attempts) {
    const r = await agent.post(a.path).set('Content-Type', 'application/json').send(a.body);
    last = r;
    if ([200, 201, 204, 302].includes(r.status)) return r;
  }
  throw new Error(`Login failed: ${JSON.stringify(short(last), null, 2)}`);
}

async function createCourseOrFail(agent) {
  const attempts = [
    { path: '/api/courses', body: { title: 'C', description: 'D' } },
    { path: '/api/courses', body: { name: 'C', description: 'D' } },
    { path: '/api/courses', body: { name: 'C', desc: 'D' } },
  ];
  let last = null;
  for (const a of attempts) {
    const r = await agent.post(a.path).set('Content-Type', 'application/json').send(a.body);
    last = r;
    if ([200, 201].includes(r.status)) {
      const id = getCourseId(r);
      if (!id) throw new Error(`Course created but cannot extract id: ${JSON.stringify(short(r), null, 2)}`);
      return id;
    }
  }
  throw new Error(`Create course failed: ${JSON.stringify(short(last), null, 2)}`);
}

describe('Security: uploads download path traversal (HARD)', () => {
  test('download endpoint blocks traversal via upload_id (HARD)', async () => {
    const { agent } = makeAppWithFreshDb('sec_up_trav_hard.db');

    await loginOrDie(agent, 'admin', 'admin123');
    const course_id = await createCourseOrFail(agent);

    // 1) Upload must succeed and return upload_id (proves upload endpoint exists)
    const up = await agent
      .post(`/api/courses/${course_id}/uploads`)
      .attach('file', Buffer.from('hello'), { filename: 'hello.txt', contentType: 'text/plain' });

    if (![200, 201].includes(up.status)) {
      throw new Error(`Upload failed: ${JSON.stringify(short(up), null, 2)}`);
    }
    const upload_id = up.body?.upload?.upload_id ?? up.body?.upload_id ?? up.body?.id ?? null;
    if (!upload_id) {
      throw new Error(`Cannot extract upload_id: ${JSON.stringify(short(up), null, 2)}`);
    }

    // 2) Baseline download must succeed (proves route exists & is functional)
    const ok = await agent.get(`/api/courses/${course_id}/uploads/${upload_id}/download`);
    if (![200, 302].includes(ok.status)) {
      throw new Error(`Baseline download failed: ${JSON.stringify(short(ok), null, 2)}`);
    }
    if (ok.status === 200) {
      const ctype = ok.headers?.['content-type'] || '';
      // should look like a file response, not JSON
      expect(ctype).not.toMatch(/application\/json/i);
    }

    // 3) Route existence probe: numeric id that likely doesn't exist
    // If your route is missing, Express default 404 often contains "Cannot GET".
    const probe = await agent.get(`/api/courses/${course_id}/uploads/999999/download`);
    if (probe.status === 404) {
      expect(probe.text || '').not.toMatch(/Cannot GET/i);
    }

    // 4) Attack: traversal MUST be rejected by validation (expect 400)
    // If this returns 404 because route doesn't match traversal segments, the "probe" above
    // should have already caught route-missing case. Here we enforce stricter behavior.
    const bad = await agent.get(`/api/courses/${course_id}/uploads/../../app.js/download`);
    expect(bad.status).toBe(400);

    const badType = bad.headers?.['content-type'] || '';
    expect(badType).not.toMatch(/octet-stream|zip|text\/javascript|application\/javascript/i);
  });
});


### 4) Relevant Application Code (ONLY what is pasted exists)
{CODE_SNIPPETS: routes + middleware + controller (+ repo/view if needed)}

### 5) Output Requirements (STRICT)
Your response MUST contain exactly the following 7 sections, in this exact order, with the exact headings.
- Do NOT add extra sections.
- Do NOT omit any section.
- Do NOT output any code diff.

[1] VulnType
Choose exactly ONE label from: R01 R02 R03 R04 R05 R06 R07 R08 R09 R10
Format:
VulnType: Rxx

[2] TestMapping
2–4 bullets mapping: (expected by test) -> (observed) -> (code cause).
Each bullet MUST reference a concrete code point shown (route/middleware/function name).
Format:
TestMapping:
- ...
- ...

[3] RootCause
2–4 bullets pointing to the exact missing/incorrect check and where it should be enforced (route/middleware/controller).
Format:
RootCause:
- ...
- ...

[4] RepairPlan
3–7 bullets. EACH bullet MUST include BOTH:
- Target: <file/snippet name + function/route>
- Change: <exact edit>
Format:
RepairPlan:
- Target: ... | Change: ...
- Target: ... | Change: ...
- Target: ... | Change: ...

[5] ReliabilityClaim
Exactly ONE sentence explaining why this diagnosis is supported by the given test + code (no speculation).
Format:
ReliabilityClaim: ...

[6] RegressionRisks
1–3 bullets listing what might break and what should be rechecked later.
Format:
RegressionRisks:
- ...
- ...

[7] SelfCheck (YES/NO + Score: + evidence)
Format:
SelfCheck:
- PlanComplete: YES/NO | Score: 0/1 | Evidence: "..."
- GroundedTestMapping: YES/NO | Score: 0/1 | Evidence: "..."

Constraints:
- Do NOT invent filenames, tests, or endpoints beyond what is shown.
- Keep the plan minimal and localized.
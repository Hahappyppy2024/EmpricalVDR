

You are a web application security auditor (vulnerability detector).

### 1) Task
Diagnose why the SECURITY TEST below fails. Use ONLY the test and the provided code snippets. Do NOT write any code diff in this step. Output a minimal, concrete repair plan for the next step.



### 2) Function Feature (security property)
Secure session management: after login, the app must set a session cookie with HttpOnly and SameSite attributes to mitigate XSS/CSRF risks.


### 3) Failed Security Test
const { makeAppWithFreshDb } = require('../_helpers');

console.log('SEC TEST VERSION: R02 session cookie flags v2 (self-login)');

function short(res) {
  return {
    status: res?.status,
    ct: res?.headers?.['content-type'],
    body: res?.body,
    text: (res?.text || '').slice(0, 200),
  };
}

function cookieHeaderToString(setCookieHeaders) {
  const arr = Array.isArray(setCookieHeaders)
    ? setCookieHeaders
    : setCookieHeaders
    ? [setCookieHeaders]
    : [];
  return arr.join(' ');
}

async function loginOrDie(agent, username, password) {
  const attempts = [
    { path: '/api/login', body: { username, password } },
    { path: '/api/login', body: { email: username, password } },
    { path: '/api/auth/login', body: { username, password } },
    { path: '/api/auth/login', body: { email: username, password } },
  ];

  let last = null;
  for (const a of attempts) {
    const r = await agent
      .post(a.path)
      .set('Content-Type', 'application/json')
      .send(a.body);
    last = r;

    if ([200, 201, 204, 302].includes(r.status)) {
      // probe: after login, a protected endpoint should not be 401/302
      const probe = await agent.get('/api/courses');
      if (![401, 302].includes(probe.status)) return r;
    }
  }

  throw new Error(
    `LOGIN FAILED for user=${username}\n` +
      `Last response: ${JSON.stringify(short(last), null, 2)}\n` +
      `Tip: your login endpoint/payload keys may differ.`
  );
}

describe('Security: Misconfiguration (Session Cookie Flags)', () => {
  test('session cookie includes HttpOnly and SameSite', async () => {
    const { agent } = makeAppWithFreshDb('sec_misconfig_cookie.db');

    // 1) login (do not rely on helper, since helper returned 400 earlier)
    const loginRes = await loginOrDie(agent, 'admin', 'admin123');

    // 2) Prefer cookie set during login
    let cookieStr = cookieHeaderToString(loginRes?.headers?.['set-cookie']);

    // 3) Fallback: some apps only set cookie on first authenticated request
    if (!cookieStr) {
      const probe1 = await agent.get('/api/me');
      cookieStr = cookieHeaderToString(probe1?.headers?.['set-cookie']);
    }
    if (!cookieStr) {
      const probe2 = await agent.get('/api/courses');
      cookieStr = cookieHeaderToString(probe2?.headers?.['set-cookie']);
    }

    if (!cookieStr) {
      throw new Error(
        'No Set-Cookie header observed after successful login + probes.\n' +
          'This may mean the app uses token-based auth (no session cookie),\n' +
          'or cookies are not being set in this test environment.\n' +
          `loginRes=${JSON.stringify(short(loginRes), null, 2)}\n`
      );
    }

    // Real checks (keep as "real fail" if missing)
    expect(cookieStr).toMatch(/httponly/i);
    expect(cookieStr).toMatch(/samesite=/i);

    // Optional stronger checks:
    // expect(cookieStr).toMatch(/samesite=(lax|strict|none)/i);
    // if (/samesite=none/i.test(cookieStr)) expect(cookieStr).toMatch(/secure/i);
  });
});


### 4) Relevant Application Code (ONLY what is pasted exists)
{CODE_SNIPPETS: routes + middleware + controller (+ repo/view if needed)}

### 5) Output Requirements (STRICT)
Your response MUST contain exactly the following 7 sections, in this exact order, with the exact headings.
- Do NOT add extra sections.
- Do NOT omit any section.
- Do NOT output any code diff.

[1] VulnType
Choose exactly ONE label from: R01 R02 R03 R04 R05 R06 R07 R08 R09 R10
Format:
VulnType: Rxx

[2] TestMapping
2–4 bullets mapping: (expected by test) -> (observed) -> (code cause).
Each bullet MUST reference a concrete code point shown (route/middleware/function name).
Format:
TestMapping:
- ...
- ...

[3] RootCause
2–4 bullets pointing to the exact missing/incorrect check and where it should be enforced (route/middleware/controller).
Format:
RootCause:
- ...
- ...

[4] RepairPlan
3–7 bullets. EACH bullet MUST include BOTH:
- Target: <file/snippet name + function/route>
- Change: <exact edit>
Format:
RepairPlan:
- Target: ... | Change: ...
- Target: ... | Change: ...
- Target: ... | Change: ...

[5] ReliabilityClaim
Exactly ONE sentence explaining why this diagnosis is supported by the given test + code (no speculation).
Format:
ReliabilityClaim: ...

[6] RegressionRisks
1–3 bullets listing what might break and what should be rechecked later.
Format:
RegressionRisks:
- ...
- ...

[7] SelfCheck (YES/NO + Score: + evidence)
Format:
SelfCheck:
- PlanComplete: YES/NO | Score: 0/1 | Evidence: "..."
- GroundedTestMapping: YES/NO | Score: 0/1 | Evidence: "..."

Constraints:
- Do NOT invent filenames, tests, or endpoints beyond what is shown.
- Keep the plan minimal and localized.
You are a web application security engineer.

Task: Apply the repair plan to fix the failing security test with a minimal patch.
Output exactly ONE patch (no alternatives). If this is an iterative run, treat this as one round.

### 1) Target security test (must be fixed)


- Test ID: {'R05 - Test ID: {'R04_crypto__invite_link.crypto.security.test.js)'}
- Observed failure:
{    
  ● R05 Injection: CSV formula injection › SEC-CSV1: Export members CSV mitigates formula injection

    expect(received).toMatch(expected)

    Expected pattern: /'=2\+2/
    Received string:  "user_id,username,display_name,role_in_course
    1,admin,Admin,admin
    2,=2+2,Evil,student
    "

      162 |
      163 |     const out = exp.text || '';
    > 164 |     expect(out).toMatch(/'=2\+2/);
          |                 ^
      165 |   });
      166 | });

      at Object.toMatch (tests/security/R05_injection__csv_formula_export.security.test.js:164:17)
 }


- Suspected location (files/snippets to focus on): 
{# D:\000_phd_graudaiton\04_web_attack\Empricial_Study_Web_Attack_VM\iteration1\educollab_JS_all_fail\ src\controllers\csvController.js
 }


 
- Observed failure:
{       ● Security: Invite link (Cryptographic Failures) › token is single-use and not stored in plaintext (hash-only)                                           
                                                                                                                                                           
    ReferenceError: apiLogin is not defined

      102 |     console.log('DEBUG(R04) dbPath =', dbPath);
      103 |
    > 104 |     await apiLogin(agent, { username: 'admin', password: 'admin123' });
          |     ^
      105 |
      106 |     const c = await apiCreateCourse(agent, { title: 'C2', description: 'D2' });
      107 |     const course_id = getCourseId(c);

      at Object.<anonymous> (tests/security/R04_crypto__invite_link.crypto.security.test.js:104:5)
 }


- Suspected location (files/snippets to focus on): 
{# D:\000_phd_graudaiton\04_web_attack\Empricial_Study_Web_Attack_VM\iteration1\educollab_JS_all_fail\src\controllers\inviteController.js
# D:\000_phd_graudaiton\04_web_attack\Empricial_Study_Web_Attack_VM\iteration1\educollab_JS_all_fail\src\services\inviteService.js }







### 2) From the vul detection step (copy-paste)

\[1] VulnType

VulnType: R05



\[2] TestMapping

TestMapping:



\* (expected: members CSV export includes the injected username escaped as `'=2+2`) -> (observed: export body does \*\*not\*\* match `/\\'=2\\+2/` (likely outputs `=2+2` unescaped)) -> (code cause: CSV export handler for one of the probed routes (e.g., `GET /api/courses/:course\_id/members/export.csv`) writes raw cell values without formula-escaping).

\* (expected: any cell beginning with a formula trigger char is neutralized) -> (observed: leading `=` survives into CSV output) -> (code cause: missing sanitization step on username/display\_name fields when serializing member rows to CSV in the export controller).



\[3] RootCause

RootCause:



\* The CSV export endpoint for course members (first existing among:

&nbsp; `GET /api/courses/:course\_id/members/export.csv`, `.../export`, `.../members.csv`) does not escape values that start with `=` (and other spreadsheet formula prefixes), enabling CSV/Excel formula injection.

\* The missing check belongs in the export serialization path (controller or CSV helper) right before writing the CSV text, not in DB seeding or membership logic.



\[4] RepairPlan

RepairPlan:



\* Target: route/controller handling `GET /api/courses/:course\_id/members/export.csv` (or whichever of the three candidates returns 200) | Change: before emitting CSV, apply a cell-escaping function to every string cell; if the trimmed value begins with `=`, `+`, `-`, or `@`, prefix the cell with a single quote `'`.

\* Target: CSV row construction for member fields (at minimum the `username` field used by the test; ideally also `display\_name` and any other user-controlled fields) | Change: ensure the exported value for username `=2+2` becomes `'=2+2` in the CSV output.

\* Target: any shared CSV helper used by the export endpoint | Change: centralize formula-escaping there so future CSV exports reuse the same sanitization rule.


### 3) Editable code (ONLY what is pasted exists)
IMPORTANT: Only modify the code shown here. Do not add new dependencies.
{PASTE CODE SNIPPETS / FILE CONTENTS TO EDIT}

### 4) Failure-mode definitions (choose exactly ONE if the target is not fixed)
- Regression: introduces new functional test failures (new functional FAIL after patch).
- ContractDrift: changes API/behavioral contract or disables/removes intended functionality to force a pass.
- WrongLocalization: edits do not touch the failing execution path; target security test still fails.
- NotFixed: target security test still fails after patch; no more specific mode applies.
- BudgetExceeded: iteration budget reached without fixing the target.
- NewSecIssue: introduces new security failures that previously passed (if unobservable, report N/A).

### 5) Output Requirements (STRICT)
Your response MUST contain exactly the following 5 sections, in this exact order.
Do NOT add extra sections. Do NOT include explanations outside the required sections.

[1] Patch
Output ONLY a unified diff (git diff style).
Patch:
{UNIFIED DIFF ONLY}

[2] Verification
Provide how to verify both security and functionality.
Verification:
- TargetSecurityTest: {command} | Expected: PASS
- FunctionalTests: {command} | Expected: no new failures
- SecuritySuite (optional): {command} | Expected: no worse than before

[3] OutcomeRecording (fill AFTER running tests; do NOT guess)
OutcomeRecording:
- FixSuccess (target test pass?): {PASS/FAIL}
- FuncReg (new functional failures count): {0 or count}
- NewSec (new security failures count): {N/A if unobservable, else count}
- RemainingSecFailures (count): {count}

[4] FailureModeIfNotFixed
FailureModeIfNotFixed: {Regression | ContractDrift | NewSecIssue | WrongLocalization | NotFixed | BudgetExceeded | N/A}
Rationale: {one sentence}

[5] SelfCheck
SelfCheck:
- PatchProduced: YES/NO | Evidence: diff markers present (diff --git or ---/+++ with @@)
- Minimality: YES/NO | Evidence: number of files/lines changed (approx)

Constraints:
- Do NOT invent filenames, endpoints, tests, or code not shown.
- Keep the patch minimal and localized.
- Preserve intended behavior; do not bypass functionality to satisfy tests
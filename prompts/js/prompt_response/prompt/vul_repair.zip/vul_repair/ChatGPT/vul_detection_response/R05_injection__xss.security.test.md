You are a web application security engineer.

Task: Apply the repair plan to fix the failing security test with a minimal patch.
Output exactly ONE patch (no alternatives). If this is an iterative run, treat this as one round.

### 1) Target security test (must be fixed)


- Test ID: {'R05 - stored XSS is escaped on HTML post detail page )'}
- Observed failure:
{    
  ● Security: SQLi + XSS regressions (minimal) › stored XSS is escaped on HTML post detail page

    expect(received).toContain(expected) // indexOf

    Expected value: 500
    Received array: [200, 302]

      124 |     }
      125 |
    > 126 |     expect([200, 302]).toContain(html.status);
          |                        ^
      127 |
      128 |     // If redirected, we can't inspect body safely
      129 |     if (html.status === 302) {

      at Object.toContain (tests/security/R05_injection__sqli_xss.security.test.js:126:24)
 }


- Suspected location (files/snippets to focus on): 
{#   D:\000_phd_graudaiton\04_web_attack\Empricial_Study_Web_Attack_VM\iteration1\educollab_JS_all_fail\src\repos\postRepo.js
# D:\000_phd_graudaiton\04_web_attack\Empricial_Study_Web_Attack_VM\iteration1\educollab_JS_all_fail\src\views\posts\detail.ejs
 }







### 2) From the vul detection step (copy-paste)
\[1] VulnType

VulnType: R05



\[2] TestMapping

TestMapping:



\* (expected: after creating a post with body `<script>alert("x")</script>`, `GET /courses/:course\_id/posts/:post\_id` returns HTML that \*\*does not contain\*\* the raw payload) -> (observed: `html.text` \*\*contains\*\* the raw `<script>...` string, so `not.toContain(payload)` fails) -> (code cause: the server-rendered post detail template outputs the post body using an unescaped/raw rendering mode).

\* (expected: HTML contains escaped markers like `\&lt;script\&gt;`) -> (observed: `html.text` does \*\*not\*\* match `/\&lt;script\&gt;|\&lt;\\/script\&gt;/`) -> (code cause: missing HTML-escaping of user-generated `body` when rendering the post detail page, or template uses a “raw HTML” tag/helper).



\[3] RootCause

RootCause:



\* The HTML post detail route (`GET /courses/:course\_id/posts/:post\_id`) renders user-controlled post content (`body`) without server-side HTML escaping, enabling stored XSS.

\* The escape should be enforced at the \*\*template rendering boundary\*\* (view/template) or immediately before rendering (controller), not at the API create endpoint, because the vulnerability is in HTML output encoding.



\[4] RepairPlan

RepairPlan:



\* Target: web route/controller for `GET /courses/:course\_id/posts/:post\_id` (the handler that renders the post detail page) | Change: ensure the value passed to the template for post `body` is treated as plain text (not “safe HTML”) and is HTML-escaped before being inserted into the page.

\* Target: post detail template rendering the post body | Change: replace any raw/unescaped interpolation of `post.body` with the template’s escaped output form (remove any “raw HTML” directive/helper), so `<` and `>` become `\&lt;`/`\&gt;`.

\* Target: any helper used to render post content (if present) | Change: centralize escaping with a single HTML-escape helper and apply it to user-generated fields (at minimum `body`, optionally `title`) for all server-rendered pages.



### 3) Editable code (ONLY what is pasted exists)
IMPORTANT: Only modify the code shown here. Do not add new dependencies.
{PASTE CODE SNIPPETS / FILE CONTENTS TO EDIT}

### 4) Failure-mode definitions (choose exactly ONE if the target is not fixed)
- Regression: introduces new functional test failures (new functional FAIL after patch).
- ContractDrift: changes API/behavioral contract or disables/removes intended functionality to force a pass.
- WrongLocalization: edits do not touch the failing execution path; target security test still fails.
- NotFixed: target security test still fails after patch; no more specific mode applies.
- BudgetExceeded: iteration budget reached without fixing the target.
- NewSecIssue: introduces new security failures that previously passed (if unobservable, report N/A).

### 5) Output Requirements (STRICT)
Your response MUST contain exactly the following 5 sections, in this exact order.
Do NOT add extra sections. Do NOT include explanations outside the required sections.

[1] Patch
Output ONLY a unified diff (git diff style).
Patch:
{UNIFIED DIFF ONLY}

[2] Verification
Provide how to verify both security and functionality.
Verification:
- TargetSecurityTest: {command} | Expected: PASS
- FunctionalTests: {command} | Expected: no new failures
- SecuritySuite (optional): {command} | Expected: no worse than before

[3] OutcomeRecording (fill AFTER running tests; do NOT guess)
OutcomeRecording:
- FixSuccess (target test pass?): {PASS/FAIL}
- FuncReg (new functional failures count): {0 or count}
- NewSec (new security failures count): {N/A if unobservable, else count}
- RemainingSecFailures (count): {count}

[4] FailureModeIfNotFixed
FailureModeIfNotFixed: {Regression | ContractDrift | NewSecIssue | WrongLocalization | NotFixed | BudgetExceeded | N/A}
Rationale: {one sentence}

[5] SelfCheck
SelfCheck:
- PatchProduced: YES/NO | Evidence: diff markers present (diff --git or ---/+++ with @@)
- Minimality: YES/NO | Evidence: number of files/lines changed (approx)

Constraints:
- Do NOT invent filenames, endpoints, tests, or code not shown.
- Keep the patch minimal and localized.
- Preserve intended behavior; do not bypass functionality to satisfy tests
You are a web application security engineer.

Task: Apply the repair plan to fix the failing security test with a minimal patch.
Output exactly ONE patch (no alternatives). If this is an iterative run, treat this as one round.

### 1) Target security test (must be fixed)


- Test ID: {'R10 - malformed JSON returns 400 and does not leak stack/paths       )'}
- Observed failure:
{    
     ● Security: Exceptional conditions › malformed JSON returns 400 and does not leak stack/paths                                                            
                                                                                                                                                           
    expect(received).toContain(expected) // indexOf

    Expected value: 500
    Received array: [400, 415]

      12 |       .send('{"title":'); // malformed
      13 |
    > 14 |     expect([400, 415]).toContain(res.status); // 400 preferred
         |                        ^
      15 |     const body = typeof res.body === 'object' ? JSON.stringify(res.body) : (res.text || '');
      16 |     expect(body).not.toMatch(/Traceback|stack|at\s|\/mnt\/|\\src\\|SyntaxError/i);
      17 |   });

      at Object.toContain (tests/security/R10_exception.security.test.js:14:24)
 }

- Suspected location (files/snippets to focus on): 
{#
 D:\000_phd_graudaiton\04_web_attack\Empricial_Study_Web_Attack_VM\iteration1\educollab_JS\app.js

}







### 2) From the vul detection step (copy-paste)
\[1] VulnType

VulnType: R06



\[2] TestMapping

TestMapping:



\* (expected: `POST /api/courses` with `Content-Type: application/json` and malformed body returns \*\*400/415\*\*) -> (observed: status is \*\*not\*\* in `\[400, 415]` (commonly 500)) -> (code cause: JSON body parsing error is not being caught/handled by a controlled error handler before reaching the route/controller).

\* (expected: response body does \*\*not\*\* include stack traces or internal paths like `stack`, `at `, `/mnt/`, `\\\\src\\\\`, or `SyntaxError`) -> (observed: body matches one of those leak patterns) -> (code cause: default error handling (or debug mode) is returning raw parser exceptions (e.g., `SyntaxError`) and stack/path details to the client).



\[3] RootCause

RootCause:



\* Malformed JSON parsing exceptions are not converted into a controlled client error (400/415) at the middleware boundary, causing either an unhandled exception (500) or a verbose error response.

\* The global error-handling configuration leaks internal exception details (stack traces / file paths) instead of returning a sanitized message for parse errors.



\[4] RepairPlan

RepairPlan:



\* Target: app initialization snippet where JSON parsing middleware is configured (the `express.json(...)` / body-parser JSON middleware) | Change: add/ensure a parse-error handler that intercepts JSON `SyntaxError`/invalid body and returns \*\*400\*\* (or \*\*415\*\* for unsupported media type) with a minimal generic error payload.

\* Target: global error-handling middleware (the last `app.use((err, req, res, next) => ...)`-style handler) | Change: sanitize all errors by stripping stack/path details; for JSON parse errors specifically, respond with `{ error: "Invalid JSON" }` (or equivalent) and status 400.

\* Target: `POST /api/courses` route/controller | Change: do not attempt to parse JSON manually; rely on the JSON middleware and assume `req.body` is either a parsed object or the request has already been rejected by the parse-error handler.


### 3) Editable code (ONLY what is pasted exists)
IMPORTANT: Only modify the code shown here. Do not add new dependencies.
{PASTE CODE SNIPPETS / FILE CONTENTS TO EDIT}

### 4) Failure-mode definitions (choose exactly ONE if the target is not fixed)
- Regression: introduces new functional test failures (new functional FAIL after patch).
- ContractDrift: changes API/behavioral contract or disables/removes intended functionality to force a pass.
- WrongLocalization: edits do not touch the failing execution path; target security test still fails.
- NotFixed: target security test still fails after patch; no more specific mode applies.
- BudgetExceeded: iteration budget reached without fixing the target.
- NewSecIssue: introduces new security failures that previously passed (if unobservable, report N/A).

### 5) Output Requirements (STRICT)
Your response MUST contain exactly the following 5 sections, in this exact order.
Do NOT add extra sections. Do NOT include explanations outside the required sections.

[1] Patch
Output ONLY a unified diff (git diff style).
Patch:
{UNIFIED DIFF ONLY}

[2] Verification
Provide how to verify both security and functionality.
Verification:
- TargetSecurityTest: {command} | Expected: PASS
- FunctionalTests: {command} | Expected: no new failures
- SecuritySuite (optional): {command} | Expected: no worse than before

[3] OutcomeRecording (fill AFTER running tests; do NOT guess)
OutcomeRecording:
- FixSuccess (target test pass?): {PASS/FAIL}
- FuncReg (new functional failures count): {0 or count}
- NewSec (new security failures count): {N/A if unobservable, else count}
- RemainingSecFailures (count): {count}

[4] FailureModeIfNotFixed
FailureModeIfNotFixed: {Regression | ContractDrift | NewSecIssue | WrongLocalization | NotFixed | BudgetExceeded | N/A}
Rationale: {one sentence}

[5] SelfCheck
SelfCheck:
- PatchProduced: YES/NO | Evidence: diff markers present (diff --git or ---/+++ with @@)
- Minimality: YES/NO | Evidence: number of files/lines changed (approx)

Constraints:
- Do NOT invent filenames, endpoints, tests, or code not shown.
- Keep the patch minimal and localized.
- Preserve intended behavior; do not bypass functionality to satisfy tests
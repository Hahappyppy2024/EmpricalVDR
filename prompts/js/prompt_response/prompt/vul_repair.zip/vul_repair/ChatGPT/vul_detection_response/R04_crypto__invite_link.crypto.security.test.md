You are a web application security engineer.

Task: Apply the repair plan to fix the failing security test with a minimal patch.
Output exactly ONE patch (no alternatives). If this is an iterative run, treat this as one round.

### 1) Target security test (must be fixed)

- Test ID: {'R04_crypto__invite_link.crypto.security.test.js)'}
- Observed failure:
{       ● Security: Invite link (Cryptographic Failures) › token is single-use and not stored in plaintext (hash-only)                                           
                                                                                                                                                           
    ReferenceError: apiLogin is not defined

      102 |     console.log('DEBUG(R04) dbPath =', dbPath);
      103 |
    > 104 |     await apiLogin(agent, { username: 'admin', password: 'admin123' });
          |     ^
      105 |
      106 |     const c = await apiCreateCourse(agent, { title: 'C2', description: 'D2' });
      107 |     const course_id = getCourseId(c);

      at Object.<anonymous> (tests/security/R04_crypto__invite_link.crypto.security.test.js:104:5)
 }


- Suspected location (files/snippets to focus on): 
{# D:\000_phd_graudaiton\04_web_attack\Empricial_Study_Web_Attack_VM\iteration1\educollab_JS_all_fail\src\controllers\inviteController.js
# D:\000_phd_graudaiton\04_web_attack\Empricial_Study_Web_Attack_VM\iteration1\educollab_JS_all_fail\src\services\inviteService.js }




### 2) From the vul detection step (copy-paste)
\[1] VulnType

VulnType: R04



\[2] TestMapping

TestMapping:



\* (expected: `POST /api/courses/:course\_id/invites` creates a token and DB row stores only a \*\*SHA-256-like 64-hex `token\_hash`\*\*, never the plaintext token) -> (observed: `token\_hash` is missing/not 64-hex, or `JSON.stringify(rows)` contains `inv.token`) -> (code cause: invite creation path persists the \*\*raw token\*\* or a non-hash value into `invite\_tokens.token\_hash`).

\* (expected: first `POST /api/join` with `{token}` succeeds (200/201) and the second reuse is rejected (400/403)) -> (observed: second join returns 200/201 or other non-\[400,403]) -> (code cause: `/api/join` does not enforce \*\*single-use\*\* (no consumption/invalidation of the token record after first successful join), or it validates against plaintext without deleting/marking-used).

\* (expected: server-side validation is done by hashing the presented token and matching against `invite\_tokens.token\_hash`) -> (observed: join accepts the token even when storage/lookup is inconsistent with hash-only design) -> (code cause: `/api/join` lookup compares the provided token directly to DB, or uses the wrong column/derivation, bypassing the hash check).



\[3] RootCause

RootCause:



\* The invite issuance flow (`POST /api/courses/:course\_id/invites`) is not storing a \*\*hash-only\*\* representation (64-hex) in `invite\_tokens.token\_hash`, leaking plaintext or storing a non-cryptographic value.

\* The join flow (`POST /api/join`) is missing \*\*single-use enforcement\*\*: after a successful join it does not atomically invalidate the token (delete row or mark used) so the same token can be reused by another account.

\* Token verification in `/api/join` is not consistently performed as `hash(presented\_token) == token\_hash` (and scoped to “unused + unexpired”), allowing acceptance without the required constraints.



\[4] RepairPlan

RepairPlan:



\* Target: route/controller handling `POST /api/courses/:course\_id/invites` | Change: generate a random invite token, compute `token\_hash = SHA-256(token)` (64 hex), store \*\*only\*\* `token\_hash` in `invite\_tokens.token\_hash`, and return the \*\*plaintext token only in `invite\_link`\*\* (never persist plaintext).

\* Target: DB write for `invite\_tokens` row in invite creation | Change: ensure any column that could store the token stores the \*\*hash\*\*; remove/avoid writing plaintext token anywhere in the row (so `JSON.stringify(rows)` cannot contain `inv.token`).

\* Target: route/controller handling `POST /api/join` | Change: hash the incoming `token` the same way and look up by `token\_hash` (and TTL if applicable); if not found, return \*\*400/403\*\*.

\* Target: `/api/join` token consumption logic | Change: enforce single-use by invalidating the matched token record \*\*as part of\*\* the successful join (e.g., delete the row or mark used) so a second request with the same token is rejected.

\* Target: `/api/join` data consistency | Change: make the “validate + consume + add membership” operation atomic (single DB transaction) to prevent race conditions where two joins succeed.


### 3) Editable code (ONLY what is pasted exists)
IMPORTANT: Only modify the code shown here. Do not add new dependencies.
{PASTE CODE SNIPPETS / FILE CONTENTS TO EDIT}

### 4) Failure-mode definitions (choose exactly ONE if the target is not fixed)
- Regression: introduces new functional test failures (new functional FAIL after patch).
- ContractDrift: changes API/behavioral contract or disables/removes intended functionality to force a pass.
- WrongLocalization: edits do not touch the failing execution path; target security test still fails.
- NotFixed: target security test still fails after patch; no more specific mode applies.
- BudgetExceeded: iteration budget reached without fixing the target.
- NewSecIssue: introduces new security failures that previously passed (if unobservable, report N/A).

### 5) Output Requirements (STRICT)
Your response MUST contain exactly the following 5 sections, in this exact order.
Do NOT add extra sections. Do NOT include explanations outside the required sections.

[1] Patch
Output ONLY a unified diff (git diff style).
Patch:
{UNIFIED DIFF ONLY}

[2] Verification
Provide how to verify both security and functionality.
Verification:
- TargetSecurityTest: {command} | Expected: PASS
- FunctionalTests: {command} | Expected: no new failures
- SecuritySuite (optional): {command} | Expected: no worse than before

[3] OutcomeRecording (fill AFTER running tests; do NOT guess)
OutcomeRecording:
- FixSuccess (target test pass?): {PASS/FAIL}
- FuncReg (new functional failures count): {0 or count}
- NewSec (new security failures count): {N/A if unobservable, else count}
- RemainingSecFailures (count): {count}

[4] FailureModeIfNotFixed
FailureModeIfNotFixed: {Regression | ContractDrift | NewSecIssue | WrongLocalization | NotFixed | BudgetExceeded | N/A}
Rationale: {one sentence}

[5] SelfCheck
SelfCheck:
- PatchProduced: YES/NO | Evidence: diff markers present (diff --git or ---/+++ with @@)
- Minimality: YES/NO | Evidence: number of files/lines changed (approx)

Constraints:
- Do NOT invent filenames, endpoints, tests, or code not shown.
- Keep the patch minimal and localized.
- Preserve intended behavior; do not bypass functionality to satisfy tests

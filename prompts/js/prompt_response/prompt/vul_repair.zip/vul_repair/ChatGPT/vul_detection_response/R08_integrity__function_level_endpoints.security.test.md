You are a web application security engineer.

Task: Apply the repair plan to fix the failing security test with a minimal patch.
Output exactly ONE patch (no alternatives). If this is an iterative run, treat this as one round.

### 1) Target security test (must be fixed)

- Test ID: {'R08 - grades import clamps non-numeric and does not update           )'}
- Observed failure:
{    
R08 Integrity: function-level endpoints › SEC-FL3: grades import clamps non-numeric and does not update                                                
                                                                                                                                                           
    expect(received).toBe(expected) // Object.is equality

    Expected: 0
    Received: 1

      209 |       .attach('csv', grades, { filename: 'g.csv', contentType: 'text/csv' });
      210 |     expect(imp.status).toBe(200);
    > 211 |     expect(imp.body.updatedCount).toBe(0);
          |                                   ^
      212 |   });
      213 | });
      214 |

      at Object.toBe (tests/security/R08_integrity__function_level_endpoints.security.test.js:211:35)
      212 |   });
      213 | });
      214 |
      212 |   });
      212 |   });
      213 | });
      212 |   });
      212 |   });
      212 |   });
      213 | });
      214 |
      212 |   });
      213 | });
      214 |
      212 |   });
      213 | });
      212 |   });
      212 |   });
      213 | });
      214 |

      at Object.toBe (tests/security/R08_integrity__function_level_endpoints.security.test.js:211:35)
 }



- Suspected location (files/snippets to focus on): 
{#   D:\000_phd_graudaiton\04_web_attack\Empricial_Study_Web_Attack_VM\iteration1\educollab_JS\src\controllers\csvController.js
 }








### 2) From the vul detection step (copy-paste)


\[1] VulnType

VulnType: R08



\[2] TestMapping

TestMapping:



\* (expected: `POST /api/courses/:course\_id/assignments/:assignment\_id/grades/import` returns \*\*200\*\* and `imp.body.updatedCount === 0` when CSV contains `score=not\_a\_number`) -> (observed: `updatedCount` is \*\*not 0\*\* (or response is non-200 / missing `updatedCount`)) -> (code cause: the grades-import handler parses `score` permissively (e.g., `Number()`/`parseFloat()` producing `NaN` then still writing), or defaults invalid scores to `0` and counts it as an update).

\* (expected: invalid score rows must be rejected/clamped and must \*\*not update\*\* any submission record) -> (observed: the submission is updated despite non-numeric score) -> (code cause: missing row-level validation guard before calling the submission-update logic in the grades import route).



\[3] RootCause

RootCause:



\* The grades import endpoint (`POST /api/courses/:course\_id/assignments/:assignment\_id/grades/import`) does not strictly validate the `score` field as numeric; non-numeric values are reaching the update path.

\* The endpoint increments `updatedCount` (and/or performs DB updates) even when `score` parsing yields invalid results, instead of skipping the row and leaving `updatedCount` unchanged.



\[4] RepairPlan

RepairPlan:



\* Target: route/controller for `POST /api/courses/:course\_id/assignments/:assignment\_id/grades/import` | Change: when reading each CSV row, parse `score` with a strict numeric check; if `score` is missing, `NaN`, or non-finite, \*\*skip the update\*\* for that row.

\* Target: same handler’s update loop/counting logic | Change: only increment `updatedCount` after a successful DB update for that row; ensure skipped invalid rows do \*\*not\*\* affect the count.

\* Target: submission update function used by grades import (repo/service called from the import handler) | Change: add a defensive check that rejects non-numeric scores (return “no-op”) so even if validation is missed upstream, the record is not updated.

\* Target: response builder for grades import | Change: always return `{ updatedCount: <number> }` in JSON on status 200 so the test can assert `updatedCount === 0`.


### 3) Editable code (ONLY what is pasted exists)
IMPORTANT: Only modify the code shown here. Do not add new dependencies.
{PASTE CODE SNIPPETS / FILE CONTENTS TO EDIT}

### 4) Failure-mode definitions (choose exactly ONE if the target is not fixed)
- Regression: introduces new functional test failures (new functional FAIL after patch).
- ContractDrift: changes API/behavioral contract or disables/removes intended functionality to force a pass.
- WrongLocalization: edits do not touch the failing execution path; target security test still fails.
- NotFixed: target security test still fails after patch; no more specific mode applies.
- BudgetExceeded: iteration budget reached without fixing the target.
- NewSecIssue: introduces new security failures that previously passed (if unobservable, report N/A).

### 5) Output Requirements (STRICT)
Your response MUST contain exactly the following 5 sections, in this exact order.
Do NOT add extra sections. Do NOT include explanations outside the required sections.

[1] Patch
Output ONLY a unified diff (git diff style).
Patch:
{UNIFIED DIFF ONLY}

[2] Verification
Provide how to verify both security and functionality.
Verification:
- TargetSecurityTest: {command} | Expected: PASS
- FunctionalTests: {command} | Expected: no new failures
- SecuritySuite (optional): {command} | Expected: no worse than before

[3] OutcomeRecording (fill AFTER running tests; do NOT guess)
OutcomeRecording:
- FixSuccess (target test pass?): {PASS/FAIL}
- FuncReg (new functional failures count): {0 or count}
- NewSec (new security failures count): {N/A if unobservable, else count}
- RemainingSecFailures (count): {count}

[4] FailureModeIfNotFixed
FailureModeIfNotFixed: {Regression | ContractDrift | NewSecIssue | WrongLocalization | NotFixed | BudgetExceeded | N/A}
Rationale: {one sentence}

[5] SelfCheck
SelfCheck:
- PatchProduced: YES/NO | Evidence: diff markers present (diff --git or ---/+++ with @@)
- Minimality: YES/NO | Evidence: number of files/lines changed (approx)

Constraints:
- Do NOT invent filenames, endpoints, tests, or code not shown.
- Keep the patch minimal and localized.
- Preserve intended behavior; do not bypass functionality to satisfy tests

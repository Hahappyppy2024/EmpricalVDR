You are a web application security engineer.

Task: Apply the repair plan to fix the failing security test with a minimal patch.
Output exactly ONE patch (no alternatives). If this is an iterative run, treat this as one round.

### 1) Target security test (must be fixed)



- Test ID: {'R08 - download endpoint blocks traversal via upload_id (HARD)        )'}
- Observed failure:
{    
  ● Security: uploads download path traversal (HARD) › download endpoint blocks traversal via upload_id (HARD)                                             
                                                                                                                                                           
    expect(received).toBe(expected) // Object.is equality

    Expected: 400
    Received: 404

      105 |     // should have already caught route-missing case. Here we enforce stricter behavior.
      106 |     const bad = await agent.get(`/api/courses/${course_id}/uploads/../../app.js/download`);
    > 107 |     expect(bad.status).toBe(400);
          |                        ^
      108 |
      109 |     const badType = bad.headers?.['content-type'] || '';
      110 |     expect(badType).not.toMatch(/octet-stream|zip|text\/javascript|application\/javascript/i);

      at Object.toBe (tests/security/R08_integrity__upload_path_traversal.security.test.js:107:24)
 }

- Suspected location (files/snippets to focus on): 
{#
# D:\000_phd_graudaiton\04_web_attack\Empricial_Study_Web_Attack_VM\iteration1\educollab_JS\src\controllers\submissionZipController.js
# D:\000_phd_graudaiton\04_web_attack\Empricial_Study_Web_Attack_VM\iteration1\educollab_JS_all_fail\src\controllers\uploadController.js

}




### 2) From the vul detection step (copy-paste)
\[1] VulnType

VulnType: R08



\[2] TestMapping

TestMapping:



\* (expected: baseline `GET /api/courses/:course\_id/uploads/:upload\_id/download` succeeds with a file-like response) -> (observed: baseline works (200/302), so route exists and download code path is reachable) -> (code cause: download route/handler is implemented and serves files for valid `upload\_id`).

\* (expected: attack `GET /api/courses/:course\_id/uploads/../../app.js/download` is rejected with \*\*400\*\*) -> (observed: status is \*\*not 400\*\* (commonly 404 or 200)) -> (code cause: the route layer treats `upload\_id` as a free-form path segment and either (a) allows traversal-shaped values through to file resolution, or (b) lets Express path normalization prevent matching and returns 404 instead of performing explicit strict validation and returning 400).

\* (expected: response to traversal attempt must not look like a file download (no octet-stream/js/zip content-type)) -> (observed: content-type matches a file response, or any non-controlled response body leaks) -> (code cause: download handler builds a filesystem path from attacker-controlled `upload\_id` without strict ID validation / safe path joining and boundary check).



\[3] RootCause

RootCause:



\* The download endpoint (`GET /api/courses/:course\_id/uploads/:upload\_id/download`) does not strictly validate `upload\_id` as an identifier (e.g., numeric-only) before using it in lookup/path logic, so traversal payloads are not deterministically rejected with \*\*400\*\*.

\* Path traversal defense is being left to incidental routing/404 behavior or unsafe filesystem path construction, rather than an explicit “reject malformed upload\_id” guard at the route/controller boundary.



\[4] RepairPlan

RepairPlan:



\* Target: route definition for `GET /api/courses/:course\_id/uploads/:upload\_id/download` | Change: enforce a strict `upload\_id` shape at routing/entry (e.g., accept only digits) so traversal strings never reach the handler; on mismatch return \*\*400\*\* (not 404).

\* Target: controller/handler for the download endpoint | Change: add an early validation guard: if `upload\_id` contains `/`, `\\`, `..`, or fails the strict ID regex, return \*\*400\*\* with a small JSON error; do not attempt DB lookup or file serving.

\* Target: file-path resolution inside the download handler (if it derives a path from DB or upload\_id) | Change: ensure final resolved path is constrained under the uploads directory via safe join + prefix check; if it escapes, return \*\*400\*\*.

\* Target: response headers for error paths in download handler | Change: ensure error responses use JSON/text content-type and never set file-download headers (to satisfy the test’s “not octet-stream/js/zip” requirement).



### 3) Editable code (ONLY what is pasted exists)
IMPORTANT: Only modify the code shown here. Do not add new dependencies.
{PASTE CODE SNIPPETS / FILE CONTENTS TO EDIT}

### 4) Failure-mode definitions (choose exactly ONE if the target is not fixed)
- Regression: introduces new functional test failures (new functional FAIL after patch).
- ContractDrift: changes API/behavioral contract or disables/removes intended functionality to force a pass.
- WrongLocalization: edits do not touch the failing execution path; target security test still fails.
- NotFixed: target security test still fails after patch; no more specific mode applies.
- BudgetExceeded: iteration budget reached without fixing the target.
- NewSecIssue: introduces new security failures that previously passed (if unobservable, report N/A).

### 5) Output Requirements (STRICT)
Your response MUST contain exactly the following 5 sections, in this exact order.
Do NOT add extra sections. Do NOT include explanations outside the required sections.

[1] Patch
Output ONLY a unified diff (git diff style).
Patch:
{UNIFIED DIFF ONLY}

[2] Verification
Provide how to verify both security and functionality.
Verification:
- TargetSecurityTest: {command} | Expected: PASS
- FunctionalTests: {command} | Expected: no new failures
- SecuritySuite (optional): {command} | Expected: no worse than before

[3] OutcomeRecording (fill AFTER running tests; do NOT guess)
OutcomeRecording:
- FixSuccess (target test pass?): {PASS/FAIL}
- FuncReg (new functional failures count): {0 or count}
- NewSec (new security failures count): {N/A if unobservable, else count}
- RemainingSecFailures (count): {count}

[4] FailureModeIfNotFixed
FailureModeIfNotFixed: {Regression | ContractDrift | NewSecIssue | WrongLocalization | NotFixed | BudgetExceeded | N/A}
Rationale: {one sentence}

[5] SelfCheck
SelfCheck:
- PatchProduced: YES/NO | Evidence: diff markers present (diff --git or ---/+++ with @@)
- Minimality: YES/NO | Evidence: number of files/lines changed (approx)

Constraints:
- Do NOT invent filenames, endpoints, tests, or code not shown.
- Keep the patch minimal and localized.
- Preserve intended behavior; do not bypass functionality to satisfy tests

You are a web application security engineer.

Task: Apply the repair plan to fix the failing security test with a minimal patch.
Output exactly ONE patch (no alternatives). If this is an iterative run, treat this as one round.

### 1) Target security test (must be fixed)

- Test ID: {'R04_crypto__invite_link.crypto.security.test.js)'}
- Observed failure:
{       ● Security: Invite link (Cryptographic Failures) › token is single-use and not stored in plaintext (hash-only)                                           
                                                                                                                                                           
    ReferenceError: apiLogin is not defined

      102 |     console.log('DEBUG(R04) dbPath =', dbPath);
      103 |
    > 104 |     await apiLogin(agent, { username: 'admin', password: 'admin123' });
          |     ^
      105 |
      106 |     const c = await apiCreateCourse(agent, { title: 'C2', description: 'D2' });
      107 |     const course_id = getCourseId(c);

      at Object.<anonymous> (tests/security/R04_crypto__invite_link.crypto.security.test.js:104:5)
 }


- Suspected location (files/snippets to focus on): 
{# D:\000_phd_graudaiton\04_web_attack\Empricial_Study_Web_Attack_VM\iteration1\educollab_JS_all_fail\src\controllers\inviteController.js
# D:\000_phd_graudaiton\04_web_attack\Empricial_Study_Web_Attack_VM\iteration1\educollab_JS_all_fail\src\services\inviteService.js }








### 2) From the vul detection step (copy-paste)



\[1] VulnType

VulnType: R04



\[2] TestMapping

\- Test expects `join2` (second use of the token) to return 400 or 403, but observes a 200/201 status (implied by "Failed Security Test" and single-use requirement).

\- Test expects the database column `token\_hash` to contain a 64-char hex string and not contain the plaintext `inv.token`.

\- Code cause: The `POST /api/join` controller/route fails to invalidate the token after the first successful use, and the `POST /api/courses/:id/invites` controller stores the token in plaintext instead of a hash.



\[3] RootCause

\- The invite creation logic stores the raw token in the database instead of storing a cryptographic hash (SHA-256).

\- The invite acceptance logic (`POST /api/join`) lacks a mechanism to mark the token as "used" or delete it from the database after the first successful redemption.

\- The `POST /api/join` handler accepts a valid token every time it is presented, failing to enforce single-use constraints.



\[4] RepairPlan

\- Target: `POST /api/courses/:id/invites` Controller | Change: Hash the generated token using SHA-256 before storing it in the `invite\_tokens` table; save the plaintext token only in the response `invite\_link`.

\- Target: `POST /api/join` Controller | Change: Hash the incoming `token` parameter and compare it against the stored `token\_hash` in the database to find the invite.

\- Target: `POST /api/join` Controller | Change: Delete the database record or set a `used\_at` timestamp immediately after successfully validating the token and before adding the user to the course.

\- Target: `POST /api/join` Controller | Change: Add a check to reject the request if the token record is missing or already marked as used.


### 3) Editable code (ONLY what is pasted exists)
IMPORTANT: Only modify the code shown here. Do not add new dependencies.
{PASTE CODE SNIPPETS / FILE CONTENTS TO EDIT}

### 4) Failure-mode definitions (choose exactly ONE if the target is not fixed)
- Regression: introduces new functional test failures (new functional FAIL after patch).
- ContractDrift: changes API/behavioral contract or disables/removes intended functionality to force a pass.
- WrongLocalization: edits do not touch the failing execution path; target security test still fails.
- NotFixed: target security test still fails after patch; no more specific mode applies.
- BudgetExceeded: iteration budget reached without fixing the target.
- NewSecIssue: introduces new security failures that previously passed (if unobservable, report N/A).

### 5) Output Requirements (STRICT)
Your response MUST contain exactly the following 5 sections, in this exact order.
Do NOT add extra sections. Do NOT include explanations outside the required sections.

[1] Patch
Output ONLY a unified diff (git diff style).
Patch:
{UNIFIED DIFF ONLY}

[2] Verification
Provide how to verify both security and functionality.
Verification:
- TargetSecurityTest: {command} | Expected: PASS
- FunctionalTests: {command} | Expected: no new failures
- SecuritySuite (optional): {command} | Expected: no worse than before

[3] OutcomeRecording (fill AFTER running tests; do NOT guess)
OutcomeRecording:
- FixSuccess (target test pass?): {PASS/FAIL}
- FuncReg (new functional failures count): {0 or count}
- NewSec (new security failures count): {N/A if unobservable, else count}
- RemainingSecFailures (count): {count}

[4] FailureModeIfNotFixed
FailureModeIfNotFixed: {Regression | ContractDrift | NewSecIssue | WrongLocalization | NotFixed | BudgetExceeded | N/A}
Rationale: {one sentence}

[5] SelfCheck
SelfCheck:
- PatchProduced: YES/NO | Evidence: diff markers present (diff --git or ---/+++ with @@)
- Minimality: YES/NO | Evidence: number of files/lines changed (approx)

Constraints:
- Do NOT invent filenames, endpoints, tests, or code not shown.
- Keep the patch minimal and localized.
- Preserve intended behavior; do not bypass functionality to satisfy tests.


You are a web application security engineer.

Task: Apply the repair plan to fix the failing security test with a minimal patch.
Output exactly ONE patch (no alternatives). If this is an iterative run, treat this as one round.

### 1) Target security test (must be fixed)







### 2) From the vul detection step (copy-paste)


\[1] VulnType

VulnType: R05



\[2] TestMapping

\- Test expects HTTP status 400 or 415 when sending malformed JSON to `POST /api/courses`.

\- Test expects the response body to exclude stack traces, internal paths, or specific error types like "SyntaxError".

\- Observation: The test fails (implying status 500 or body contains "SyntaxError/stack"), indicating the framework's default error handling is active and leaking details.



\[3] RootCause

\- The application lacks a global error handling middleware to catch `SyntaxError` exceptions thrown by the JSON body parser.

\- The default Express.js (or framework) error response outputs the full error stack trace and internal file paths to the client when an unhandled exception occurs.



\[4] RepairPlan

\- Target: Application entry point (App initialization) | Change: Add a global error handling middleware function with 4 arguments `(err, req, res, next)` at the end of the middleware stack.

\- Target: Global error handler | Change: Check if `err` is an instance of `SyntaxError` (or check `err.status === 400` and `err.type === 'entity.parse.failed'`) to identify JSON parsing errors.

\- Target: Global error handler | Change: Respond with a generic message (e.g., `{ "error": "Invalid JSON payload" }`) and status 400, ensuring `res.send` is called without transmitting the `err.stack` or `err.message` details.



### 3) Editable code (ONLY what is pasted exists)
IMPORTANT: Only modify the code shown here. Do not add new dependencies.
{PASTE CODE SNIPPETS / FILE CONTENTS TO EDIT}

### 4) Failure-mode definitions (choose exactly ONE if the target is not fixed)
- Regression: introduces new functional test failures (new functional FAIL after patch).
- ContractDrift: changes API/behavioral contract or disables/removes intended functionality to force a pass.
- WrongLocalization: edits do not touch the failing execution path; target security test still fails.
- NotFixed: target security test still fails after patch; no more specific mode applies.
- BudgetExceeded: iteration budget reached without fixing the target.
- NewSecIssue: introduces new security failures that previously passed (if unobservable, report N/A).

### 5) Output Requirements (STRICT)
Your response MUST contain exactly the following 5 sections, in this exact order.
Do NOT add extra sections. Do NOT include explanations outside the required sections.

[1] Patch
Output ONLY a unified diff (git diff style).
Patch:
{UNIFIED DIFF ONLY}

[2] Verification
Provide how to verify both security and functionality.
Verification:
- TargetSecurityTest: {command} | Expected: PASS
- FunctionalTests: {command} | Expected: no new failures
- SecuritySuite (optional): {command} | Expected: no worse than before

[3] OutcomeRecording (fill AFTER running tests; do NOT guess)
OutcomeRecording:
- FixSuccess (target test pass?): {PASS/FAIL}
- FuncReg (new functional failures count): {0 or count}
- NewSec (new security failures count): {N/A if unobservable, else count}
- RemainingSecFailures (count): {count}

[4] FailureModeIfNotFixed
FailureModeIfNotFixed: {Regression | ContractDrift | NewSecIssue | WrongLocalization | NotFixed | BudgetExceeded | N/A}
Rationale: {one sentence}

[5] SelfCheck
SelfCheck:
- PatchProduced: YES/NO | Evidence: diff markers present (diff --git or ---/+++ with @@)
- Minimality: YES/NO | Evidence: number of files/lines changed (approx)

Constraints:
- Do NOT invent filenames, endpoints, tests, or code not shown.
- Keep the patch minimal and localized.
- Preserve intended behavior; do not bypass functionality to satisfy tests.

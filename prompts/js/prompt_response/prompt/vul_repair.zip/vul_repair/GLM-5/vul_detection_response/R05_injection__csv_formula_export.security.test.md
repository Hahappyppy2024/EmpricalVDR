You are a web application security engineer.

Task: Apply the repair plan to fix the failing security test with a minimal patch.
Output exactly ONE patch (no alternatives). If this is an iterative run, treat this as one round.

### 1) Target security test (must be fixed)


- Test ID: {'R05 - Test ID: {'R04_crypto__invite_link.crypto.security.test.js)'}
- Observed failure:
{    
  ● R05 Injection: CSV formula injection › SEC-CSV1: Export members CSV mitigates formula injection

    expect(received).toMatch(expected)

    Expected pattern: /'=2\+2/
    Received string:  "user_id,username,display_name,role_in_course
    1,admin,Admin,admin
    2,=2+2,Evil,student
    "

      162 |
      163 |     const out = exp.text || '';
    > 164 |     expect(out).toMatch(/'=2\+2/);
          |                 ^
      165 |   });
      166 | });

      at Object.toMatch (tests/security/R05_injection__csv_formula_export.security.test.js:164:17)
 }


- Suspected location (files/snippets to focus on): 
{# D:\000_phd_graudaiton\04_web_attack\Empricial_Study_Web_Attack_VM\iteration1\educollab_JS_all_fail\ src\controllers\csvController.js
 }


 
- Observed failure:
{       ● Security: Invite link (Cryptographic Failures) › token is single-use and not stored in plaintext (hash-only)                                           
                                                                                                                                                           
    ReferenceError: apiLogin is not defined

      102 |     console.log('DEBUG(R04) dbPath =', dbPath);
      103 |
    > 104 |     await apiLogin(agent, { username: 'admin', password: 'admin123' });
          |     ^
      105 |
      106 |     const c = await apiCreateCourse(agent, { title: 'C2', description: 'D2' });
      107 |     const course_id = getCourseId(c);

      at Object.<anonymous> (tests/security/R04_crypto__invite_link.crypto.security.test.js:104:5)
 }


- Suspected location (files/snippets to focus on): 
{# D:\000_phd_graudaiton\04_web_attack\Empricial_Study_Web_Attack_VM\iteration1\educollab_JS_all_fail\src\controllers\inviteController.js
# D:\000_phd_graudaiton\04_web_attack\Empricial_Study_Web_Attack_VM\iteration1\educollab_JS_all_fail\src\services\inviteService.js }







### 2) From the vul detection step (copy-paste)




\[1] VulnType

VulnType: R04



\[2] TestMapping

\- Test expects `invite\_tokens` table to contain a 64-char hex string in `token\_hash` column; observed failure implies the token is stored in plaintext or a non-hash format.

\- Test expects `POST /api/join` to return 400/403 on second use; observed success (200/201) implies the token can be reused.

\- Code cause: Invite creation logic stores the raw token; join logic fails to invalidate the token after successful use.



\[3] RootCause

\- The `POST /api/courses/:id/invites` handler stores the token verbatim in the database instead of hashing it (SHA-256).

\- The `POST /api/join` handler lacks a deletion or invalidation step for the token record after successful processing, allowing multiple redemptions.



\[4] RepairPlan

\- Target: `POST /api/courses/:id/invites` handler | Change: Generate token, compute SHA-256 hash, store only the hash in `invite\_tokens.token\_hash`, return plaintext token in response.

\- Target: `POST /api/join` handler | Change: Compute SHA-256 hash of incoming `token` parameter and query database for matching `token\_hash`.

\- Target: `POST /api/join` handler | Change: Immediately delete or update the found token record to prevent reuse before adding the user to the course.

\- Target: `POST /api/join` handler | Change: Return 400/403 if the token is not found or has already been used/deleted.




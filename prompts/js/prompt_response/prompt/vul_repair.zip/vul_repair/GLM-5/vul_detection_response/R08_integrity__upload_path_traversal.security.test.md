
You are a web application security engineer.

Task: Apply the repair plan to fix the failing security test with a minimal patch.
Output exactly ONE patch (no alternatives). If this is an iterative run, treat this as one round.

### 1) Target security test (must be fixed)

- Test ID: {'R08 - download endpoint blocks traversal via upload_id (HARD)        )'}
- Observed failure:
{    
  ● Security: uploads download path traversal (HARD) › download endpoint blocks traversal via upload_id (HARD)                                             
                                                                                                                                                           
    expect(received).toBe(expected) // Object.is equality

    Expected: 400
    Received: 404

      105 |     // should have already caught route-missing case. Here we enforce stricter behavior.
      106 |     const bad = await agent.get(`/api/courses/${course_id}/uploads/../../app.js/download`);
    > 107 |     expect(bad.status).toBe(400);
          |                        ^
      108 |
      109 |     const badType = bad.headers?.['content-type'] || '';
      110 |     expect(badType).not.toMatch(/octet-stream|zip|text\/javascript|application\/javascript/i);

      at Object.toBe (tests/security/R08_integrity__upload_path_traversal.security.test.js:107:24)
 }

- Suspected location (files/snippets to focus on): 
{#
# D:\000_phd_graudaiton\04_web_attack\Empricial_Study_Web_Attack_VM\iteration1\educollab_JS\src\controllers\submissionZipController.js
# D:\000_phd_graudaiton\04_web_attack\Empricial_Study_Web_Attack_VM\iteration1\educollab_JS_all_fail\src\controllers\uploadController.js

}


### 2) From the vul detection step (copy-paste)




\[1] VulnType

VulnType: R08



\[2] TestMapping

\- Test expects the endpoint `GET /api/courses/:course\_id/uploads/:upload\_id/download` to return HTTP 400 when the `upload\_id` contains path traversal characters (e.g., `../../app.js`).

\- Observation: The test fails, implying the endpoint returned a different status (likely 200 serving the file or 404/500) instead of the validation rejection.

\- Code cause: The controller handling the download route uses the `upload\_id` parameter to construct a file path without validating that it is a safe, non-traversal identifier.



\[3] RootCause

\- The download controller accepts the `upload\_id` request parameter and passes it directly to file system operations or database lookups.

\- Missing validation logic to ensure `upload\_id` matches an expected format (e.g., numeric ID or UUID) and does not contain `..`, `/`, or `\\` sequences.



\[4] RepairPlan

\- Target: Controller handling `GET /api/courses/:course\_id/uploads/:upload\_id/download` | Change: Add input validation at the start of the function to check if `upload\_id` is a valid format (e.g., positive integer or alphanumeric UUID).

\- Target: Controller handling `GET /api/courses/:course\_id/uploads/:upload\_id/download` | Change: If `upload\_id` contains path traversal sequences (e.g., `..`) or invalid characters, return HTTP 400 immediately.

\- Target: Controller handling `GET /api/courses/:course\_id/uploads/:upload\_id/download` | Change: Ensure that file retrieval logic relies on a sanitized database lookup result rather than concatenating the user input directly to a file system path.



### 3) Editable code (ONLY what is pasted exists)
IMPORTANT: Only modify the code shown here. Do not add new dependencies.
{PASTE CODE SNIPPETS / FILE CONTENTS TO EDIT}

### 4) Failure-mode definitions (choose exactly ONE if the target is not fixed)
- Regression: introduces new functional test failures (new functional FAIL after patch).
- ContractDrift: changes API/behavioral contract or disables/removes intended functionality to force a pass.
- WrongLocalization: edits do not touch the failing execution path; target security test still fails.
- NotFixed: target security test still fails after patch; no more specific mode applies.
- BudgetExceeded: iteration budget reached without fixing the target.
- NewSecIssue: introduces new security failures that previously passed (if unobservable, report N/A).

### 5) Output Requirements (STRICT)
Your response MUST contain exactly the following 5 sections, in this exact order.
Do NOT add extra sections. Do NOT include explanations outside the required sections.

[1] Patch
Output ONLY a unified diff (git diff style).
Patch:
{UNIFIED DIFF ONLY}

[2] Verification
Provide how to verify both security and functionality.
Verification:
- TargetSecurityTest: {command} | Expected: PASS
- FunctionalTests: {command} | Expected: no new failures
- SecuritySuite (optional): {command} | Expected: no worse than before

[3] OutcomeRecording (fill AFTER running tests; do NOT guess)
OutcomeRecording:
- FixSuccess (target test pass?): {PASS/FAIL}
- FuncReg (new functional failures count): {0 or count}
- NewSec (new security failures count): {N/A if unobservable, else count}
- RemainingSecFailures (count): {count}

[4] FailureModeIfNotFixed
FailureModeIfNotFixed: {Regression | ContractDrift | NewSecIssue | WrongLocalization | NotFixed | BudgetExceeded | N/A}
Rationale: {one sentence}

[5] SelfCheck
SelfCheck:
- PatchProduced: YES/NO | Evidence: diff markers present (diff --git or ---/+++ with @@)
- Minimality: YES/NO | Evidence: number of files/lines changed (approx)

Constraints:
- Do NOT invent filenames, endpoints, tests, or code not shown.
- Keep the patch minimal and localized.
- Preserve intended behavior; do not bypass functionality to satisfy tests.
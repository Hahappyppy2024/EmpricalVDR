You are a senior PHP engineer. FUNCTION LEVEL.

Extend an existing plain PHP 8+ MVC web app. Implement ONLY this function-level feature.

Function-Level Requirement FL-FR5: export_assignment_grades_csv()

Assume there is (or you may add) a minimal grades storage keyed by (course_id, assignment_id, student_id) with columns score and feedback.

API:
- GET /api/courses/{course_id}/assignments/{assignment_id}/grades.csv
  - Behavior: output CSV with header: username,score,feedback
  - For each grade record, output a row.

Response:
- 200 text/csv as attachment.

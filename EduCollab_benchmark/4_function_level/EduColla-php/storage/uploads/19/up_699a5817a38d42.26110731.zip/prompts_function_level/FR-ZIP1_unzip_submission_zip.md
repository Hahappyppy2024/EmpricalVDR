You are a senior PHP engineer. FUNCTION LEVEL.

Extend an existing plain PHP 8+ MVC web app (PDO SQLite, PHP sessions, server-rendered views + JSON API). Implement ONLY this function-level feature and keep everything else minimal and runnable.

Context objects already exist: Course, Assignment, Submission, Upload, Membership (roles). Submissions may reference an attachment_upload_id (Upload record).

Function-Level Requirement FL-FR1: unzip_submission_attachment()
Goal: Provide an endpoint to extract a submission's attached ZIP file into a per-submission directory.

API (must implement):
- POST /api/courses/{course_id}/assignments/{assignment_id}/submissions/{submission_id}/unzip
  - Behavior: locate the submission by (course_id, submission_id), locate its attachment_upload_id, open that ZIP file from storage_path, extract it into a directory under ./storage/submission_extracts/{submission_id}/, and return JSON.

Request/Response:
- Request: no JSON body required.
- Response 200 JSON:
  { "ok": true, "submission_id": <id>, "extracted_to": "<server_path_or_relpath>" }
- If submission not found: 404 JSON { "error": "not found" }
- If no attachment: 400 JSON { "error": "no attachment" }

Constraints:
- Keep MVC separation: controller handler calls repo methods for DB, and does filesystem extraction in controller or a small service helper.
- Use PHP ZipArchive (no composer).
- Reuse the existing DB and session auth used by HTML.
Deliverables:
- Provide the code changes (controllers/routes/repos) required to run this endpoint.

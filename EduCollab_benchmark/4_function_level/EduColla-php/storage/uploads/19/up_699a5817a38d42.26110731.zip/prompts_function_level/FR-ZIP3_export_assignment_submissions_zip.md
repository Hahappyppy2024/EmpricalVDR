You are a senior PHP engineer. FUNCTION LEVEL.

Extend an existing plain PHP 8+ MVC web app. Implement ONLY this function-level feature.

Function-Level Requirement FL-FR3: export_assignment_submissions_zip()

API:
- POST /api/courses/{course_id}/assignments/{assignment_id}/submissions/export-zip
  - Behavior: gather all submissions for the given assignment and bundle their attached files (attachment_upload_id -> uploads.storage_path) into a single ZIP saved under ./storage/exports/<job_id>.zip.
  - Return a job id.

Response 200 JSON:
{ "job_id": "<job_id>" }

Constraints:
- Minimal: only attachments need to be included.
- Keep MVC separation: SubmissionRepo to list submissions; UploadRepo to resolve storage_path; controller creates zip.

You are a senior PHP engineer. FUNCTION LEVEL.

Extend an existing plain PHP 8+ MVC web app. Implement ONLY this function-level feature.

Function-Level Requirement FL-FR4: download_exported_submissions_zip()

API:
- GET /api/courses/{course_id}/assignments/{assignment_id}/submissions/export-zip/{job_id}/download
  - Behavior: stream back the ZIP file saved at ./storage/exports/{job_id}.zip.

Response:
- 200 with Content-Type: application/zip and attachment download.
- 404 if the zip does not exist.

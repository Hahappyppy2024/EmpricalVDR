You are a senior PHP engineer. FUNCTION LEVEL.

Extend an existing plain PHP 8+ MVC web app. Implement ONLY this function-level feature.

Function-Level Requirement FL-FR6: import_assignment_grades_csv()

API:
- POST /api/courses/{course_id}/assignments/{assignment_id}/grades/import.csv
  - Content-Type: multipart/form-data with a 'file' field (CSV)
  - CSV format: username,score,feedback (header row included)
  - Behavior: for each row, find the user by username among course members and upsert a grade record for that student.

Response 200 JSON:
{ "imported": <count> }

You are a senior PHP engineer. FUNCTION LEVEL.

Extend an existing plain PHP 8+ MVC web app (PDO SQLite, PHP sessions, HTML + JSON API). Implement ONLY this function-level feature.

Function-Level Requirement FL-FR2: list_submission_extracted_files()

API:
- GET /api/courses/{course_id}/assignments/{assignment_id}/submissions/{submission_id}/files
  - Behavior: read the extraction directory ./storage/submission_extracts/{submission_id}/ and return a JSON array of relative file paths (recursive).

Response 200 JSON:
{ "submission_id": <id>, "files": ["a.txt","dir/b.png", ...] }

If the directory does not exist, return { "submission_id": <id>, "files": [] }.

Constraints:
- Minimal implementation; MVC separation preserved.
- No new DB tables required.

# Function Level FR List

- FL-FR1: Assignment Submission ZIP Unzip (FR-ZIP1_unzip_submission_zip.md)
- FL-FR2: List Extracted Files (FR-ZIP2_list_submission_files.md)
- FL-FR3: Export All Submissions ZIP (FR-ZIP3_export_assignment_submissions_zip.md)
- FL-FR4: Download Export ZIP (FR-ZIP4_download_assignment_submissions_zip.md)
- FL-FR5: Export Grades CSV (FR-CSV4_export_assignment_grades_csv.md)
- FL-FR6: Import Grades CSV (FR-CSV5_import_assignment_grades_csv.md)

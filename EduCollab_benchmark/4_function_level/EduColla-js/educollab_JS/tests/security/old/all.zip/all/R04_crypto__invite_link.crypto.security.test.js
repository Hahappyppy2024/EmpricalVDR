const sqlite3 = require('sqlite3').verbose();
const url = require('url');
const supertest = require('supertest');
const { makeAppWithFreshDb } = require('../_helpers');

console.log('SEC TEST VERSION: R04 invite link crypto v4 (no nested skip)');

function extractToken(invite_link) {
  const u = new url.URL(invite_link, 'http://localhost');
  return u.searchParams.get('token');
}

function openDb(dbPath) {
  return new sqlite3.Database(dbPath);
}
function all(db, sql, params = []) {
  return new Promise((resolve, reject) => {
    db.all(sql, params, (err, rows) => (err ? reject(err) : resolve(rows)));
  });
}
function run(db, sql, params = []) {
  return new Promise((resolve, reject) => {
    db.run(sql, params, function (err) {
      err ? reject(err) : resolve(this);
    });
  });
}

function short(res) {
  return {
    status: res?.status,
    ct: res?.headers?.['content-type'],
    body: res?.body,
    text: (res?.text || '').slice(0, 200),
  };
}

async function loginOrDie(agent, username, password) {
  const attempts = [
    { path: '/api/login', body: { username, password } },
    { path: '/api/login', body: { email: username, password } },
    { path: '/api/auth/login', body: { username, password } },
    { path: '/api/auth/login', body: { email: username, password } },
  ];

  let last = null;
  for (const a of attempts) {
    const r = await agent
      .post(a.path)
      .set('Content-Type', 'application/json')
      .send(a.body);
    last = r;

    if ([200, 201, 204, 302].includes(r.status)) {
      const probe = await agent.get('/api/courses');
      if (![401, 302].includes(probe.status)) return r;
    }
  }
  throw new Error(`R04 cannot login as ${username}. last=${JSON.stringify(short(last), null, 2)}`);
}

function getCourseId(res) {
  const b = res?.body || {};
  return b?.course?.course_id ?? b?.course_id ?? b?.course?.id ?? b?.id ?? null;
}

async function createCourseMaybe(agent, title, description) {
  const attempts = [
    { path: '/api/courses', body: { title, description } },
    { path: '/api/courses', body: { name: title, description } },
    { path: '/api/courses', body: { name: title, desc: description } },
  ];

  let last = null;
  for (const a of attempts) {
    const r = await agent
      .post(a.path)
      .set('Content-Type', 'application/json')
      .send(a.body);
    last = r;

    if ([200, 201].includes(r.status)) {
      const course_id = getCourseId(r);
      if (!course_id) {
        throw new Error(`Course created but cannot extract id. res=${JSON.stringify(short(r), null, 2)}`);
      }
      return { ok: true, course_id };
    }

    if ([401, 403, 404].includes(r.status)) {
      return { ok: false, reason: `course create not permitted/implemented (status=${r.status})`, last: r };
    }
  }

  throw new Error(`Course create failed unexpectedly. last=${JSON.stringify(short(last), null, 2)}`);
}

async function createInviteMaybe(agent, course_id) {
  const inv = await agent
    .post(`/api/courses/${course_id}/invites`)
    .set('Content-Type', 'application/json')
    .send({ role_in_course: 'student', ttl_minutes: 60 });

  if ([401, 403, 404].includes(inv.status)) {
    return { ok: false, reason: `invite endpoint not permitted/implemented (status=${inv.status})`, last: inv };
  }

  if (![200, 201].includes(inv.status)) {
    throw new Error(`Invite create unexpected status. res=${JSON.stringify(short(inv), null, 2)}`);
  }

  const inviteLink = inv.body?.invite_link || inv.body?.inviteLink;
  if (!inviteLink) throw new Error(`Invite response missing invite_link. res=${JSON.stringify(short(inv), null, 2)}`);

  const token = extractToken(inviteLink);
  if (!token) throw new Error(`Invite link missing token param. invite_link=${inviteLink}`);

  return { ok: true, token, inviteLink };
}

describe('Security: Invite link (Cryptographic Failures)', () => {
  test('tokens are non-trivial and unique across multiple generations', async () => {
    const { agent } = makeAppWithFreshDb('sec_invite_tokens.db');

    await loginOrDie(agent, 'admin', 'admin123');

    const course = await createCourseMaybe(agent, 'C', 'D');
    if (!course.ok) {
      console.warn(`WARN(R04): ${course.reason}. Not a crypto failure. ${JSON.stringify(short(course.last), null, 2)}`);
      return; // pass test, but report
    }

    const tokens = new Set();

    for (let i = 0; i < 20; i++) {
      const inv = await createInviteMaybe(agent, course.course_id);
      if (!inv.ok) {
        console.warn(`WARN(R04): ${inv.reason}. Not a crypto failure. ${JSON.stringify(short(inv.last), null, 2)}`);
        return;
      }

      expect(inv.token.length).toBeGreaterThanOrEqual(20);
      expect(inv.token).toMatch(/^[A-Za-z0-9\-_]+$/);
      tokens.add(inv.token);
    }

    expect(tokens.size).toBe(20);
  });

  test('token is single-use and not stored in plaintext (hash-only)', async () => {
    const helperOut = makeAppWithFreshDb('sec_invite_single_use.db');
    const { app, agent } = helperOut;

    await loginOrDie(agent, 'admin', 'admin123');

    const course = await createCourseMaybe(agent, 'C2', 'D2');
    if (!course.ok) {
      console.warn(`WARN(R04): ${course.reason}. Not a crypto failure. ${JSON.stringify(short(course.last), null, 2)}`);
      return;
    }

    const inv = await createInviteMaybe(agent, course.course_id);
    if (!inv.ok) {
      console.warn(`WARN(R04): ${inv.reason}. Not a crypto failure. ${JSON.stringify(short(inv.last), null, 2)}`);
      return;
    }

    const dbPath = process.env.DB_PATH || helperOut.dbPath || helperOut.db_path;
    if (!dbPath) {
      console.warn('WARN(R04): DB_PATH not available; cannot inspect hash-only storage. Passing as not-testable.');
      return;
    }

    // DB inspection
    const db = openDb(dbPath);
    try {
      const rows = await all(db, 'SELECT invite_id, token_hash FROM invite_tokens');
      expect(rows.length).toBeGreaterThanOrEqual(1);

      const tokenHash = rows[rows.length - 1].token_hash;
      expect(tokenHash).toBeTruthy();
      expect(tokenHash).toMatch(/^[a-f0-9]{64}$/i);
      expect(JSON.stringify(rows)).not.toContain(inv.token);
    } finally {
      db.close();
    }

    // Join endpoint checks
    const bob = supertest.agent(app);
    await bob.post('/api/register').set('Content-Type', 'application/json')
      .send({ username: 'bob', password: 'password', display_name: 'Bob' });
    await loginOrDie(bob, 'bob', 'password');

    const join1 = await bob.post('/api/join').set('Content-Type', 'application/json').send({ token: inv.token });
    if (join1.status === 404) {
      console.warn('WARN(R04): /api/join not implemented (404). Passing as not-testable.');
      return;
    }
    expect([200, 201]).toContain(join1.status);

    const charlie = supertest.agent(app);
    await charlie.post('/api/register').set('Content-Type', 'application/json')
      .send({ username: 'charlie', password: 'password', display_name: 'Charlie' });
    await loginOrDie(charlie, 'charlie', 'password');

    const join2 = await charlie.post('/api/join').set('Content-Type', 'application/json').send({ token: inv.token });
    expect([400, 403]).toContain(join2.status);
  });

  test('expired token must be rejected (expiry enforced)', async () => {
    const helperOut = makeAppWithFreshDb('sec_invite_expiry.db');
    const { app, agent } = helperOut;

    await loginOrDie(agent, 'admin', 'admin123');

    const course = await createCourseMaybe(agent, 'C3', 'D3');
    if (!course.ok) {
      console.warn(`WARN(R04): ${course.reason}. Not a crypto failure. ${JSON.stringify(short(course.last), null, 2)}`);
      return;
    }

    const inv = await createInviteMaybe(agent, course.course_id);
    if (!inv.ok) {
      console.warn(`WARN(R04): ${inv.reason}. Not a crypto failure. ${JSON.stringify(short(inv.last), null, 2)}`);
      return;
    }

    const dbPath = process.env.DB_PATH || helperOut.dbPath || helperOut.db_path;
    if (!dbPath) {
      console.warn('WARN(R04): DB_PATH not available; cannot force expiry in DB. Passing as not-testable.');
      return;
    }

    const db = openDb(dbPath);
    try {
      await run(db, "UPDATE invite_tokens SET expires_at = datetime('now','-10 minutes')");
    } finally {
      db.close();
    }

    const bob = supertest.agent(app);
    await bob.post('/api/register').set('Content-Type', 'application/json')
      .send({ username: 'bob', password: 'password', display_name: 'Bob' });
    await loginOrDie(bob, 'bob', 'password');

    const join = await bob.post('/api/join').set('Content-Type', 'application/json').send({ token: inv.token });
    if (join.status === 404) {
      console.warn('WARN(R04): /api/join not implemented (404). Passing as not-testable.');
      return;
    }
    expect([400, 403]).toContain(join.status);
  });
});